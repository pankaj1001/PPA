var mongoose = require('mongoose');
var Schema = mongoose.Schema;

var Products = new Schema({
    _id: mongoose.Types.ObjectId,
    productName:{
        type:String,
        required:true
    },
    productQuantity:{
        type:Number,
        required:true
    },
    productPrice:{
        type:Number,
        required:true
    }
});

Products.index({productName:'text'});

module.exports = mongoose.model('Products',Products);