var mongoose = require('mongoose');
var Schema = mongoose.Schema;

var Orders = new Schema({
    _id: mongoose.Types.ObjectId,
    productID:{
        type:mongoose.Types.ObjectId,
        ref:'Products',
        required:true
    },
    quantity:{
        type:Number,
        required:true
    },
    userID: {
        type:mongoose.Types.ObjectId,
        ref:'User',
        required:true
    }
});

module.exports = mongoose.model('Orders',Orders);