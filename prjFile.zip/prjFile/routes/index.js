var express = require('express');
var router = express.Router();
var mongoose = require('mongoose');
var Products = require('../models/Products');
var Orders = require('../models/Orders');
var checkAuth = require('../middleware/auth');

router.route('/addProducts').post(checkAuth,function(req,res){
  if(res.userData.role !== 'admin'){
    return res.status(401).json({
      msg:'Not Authorized'
    })
  }
  const product = new Products({
    _id:mongoose.Types.ObjectId(),
    productName:req.body.productName,
    productQuantity:req.body.productQuantity,
    productPrice:req.body.productPrice
  });
  //console.log(product)

  product.save().then((data)=>{
    res.json(data);
  }).catch((err)=>{
    res.json(err);
  })
})

router.route('/productBuy/:id').post(checkAuth,function(req,res){
  const quantity = req.body.quantity;
  const available = req.body.available;
  //console.log(res.userData);
  const id = req.params.id;

  const order = new Orders({
    _id:mongoose.Types.ObjectId(),
    quantity:req.body.quantity,
    userID:res.userData.userId,
    productID:id
  })

  order.save().then((data)=>{
    Products.update({_id:id},{$set:{
      productQuantity : available - quantity
    }}).exec()
      .then(result=>{
          console.log(result);
          res.status(200).json({data})
      })
      .catch(err=>{
          console.log(err);
          order.deleteOne(data._id);
          res.status(500).json({
              error:err
          })
      })
  })
  .catch((err)=>{
    res.json({msg:err});
  })
  

})

router.route('/products').get(checkAuth,function(req,res){
  //console.log(res.userData);
  Products.find(function(err,data){
    if(err){
      res.json(err)
    }else{
      res.json(data)
    }
  })
})

router.route('/orders').get(checkAuth,function(req,res){
  //console.log(res.userData);
  Orders.find({userID:res.userData.userId},function(err,data){
    if(err){
      res.json(err)
    }else{
      res.json(data)
    }
  })
})

router.route('/products/:productName').get(checkAuth,function(req,res){
  //console.log(req.params.productName);
  const key = req.params.productName;

  Products.find({$text:{$search:key}},function(err,data){
    if(err){
      res.json(err)
    }else{
      res.json(data)
    }
  })
})

module.exports = router;
